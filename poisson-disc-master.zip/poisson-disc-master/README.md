# poisson-disc

An implementation of poisson-disc sampling with rejection based on the paper linked
at the top of the page.  Check poisson_disc.ipynb for examples and plots.

I'm not using a quadtree.  For a faster 2D version you probably should.  In higher dimension it won't matter.

## To-do
- make swapping distance function easier
- optimize.  Use some numpy?


